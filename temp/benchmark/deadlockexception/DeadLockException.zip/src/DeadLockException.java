
/**
 * Created by IntelliJ IDEA.
 * User: Asaf
 * Date: May 29, 2003
 * Time: 10:47:41 AM
 * To change this template use Options | File Templates.
 */
public class DeadLockException extends Exception{
    public String getMessage(){
        return "DEADLOCK";
    }
}
