This directory hold the code for the software development simulation Matlab code
It was developed by Shmuel Ur and Elad Yom-Tov, IBM Haifa Research Labs
(C) IBM 2005

A demo file, example.m, is included.

Contents:
bug.m           - A prototype bug
debugging.m     - Execute a debugging process
example.m       - Demo file for a simulation
execute_tests.m - Test execution phase
program.m       - Generate a program prototype
programming.m   - Perform a programming stage
write_tests.m   - Perform a test writing stage