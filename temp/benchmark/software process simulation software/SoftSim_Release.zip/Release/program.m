function program_structure  = program (varargin)

% Create an empty program.
%

program_structure.lines = 0;
program_structure.bugs  = [];
program_structure.time  = 0;


