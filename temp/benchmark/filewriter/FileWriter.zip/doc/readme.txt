First run the MyFileWriter with file name and number of lines

Then run SoftTest with the same file name and the output file name

The errors are in the following places:

DataStorage.java: line 47

DataPrinter.java: line 25

ArrayCopier.java: line 23

