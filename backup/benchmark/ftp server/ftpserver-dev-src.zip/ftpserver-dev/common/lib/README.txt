Binary Distribution
--------------------
You can keep your other jar files here. All the jar files in this directory 
will be available to the FTP server.


Source Distribution
-------------------
Maven copies all the dependent jar files here if you run ftpserver:build goal.
You can keep your other jar files in this directory. The FTP server scripts 
add all the jar files in this directory in CLASSPATH.
