You can find two sample configuration files here. One is a properties
file based configuration file and the other is a XML file based 
configuration file.